/*
     Style Node Script (SNS) from Codino 
     Version : 1.0.1
     Site : Codinodevs.ir/SNS/Script/
 */



const dom = document;
const page = window;
const information = navigator;
const _NewLine = "\n";

const public = {
    log: function(value) {
        console.log(value);
    },
    error: function(value) {
        console.error(value);
    },
    warn: function(value) {
        console.warn(value);
    },
    gap: function() {
        console.group();
    },
    gapend: function() {
        console.groupEnd();
    }
}


const on = {
    click: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("click", function() {
            func();
        });
    },
    drag: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("drag", function() {
            func();
        });
    },
    dblclick: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("dblclick", function() {
            func();
        });
    },
    keyup: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("keyup", function() {
            func();
        });
    },
    mouseover: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("mouseover", function() {
            func();
        });
    },
    mouseout: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("mouseout", function() {
            func();
        });
    },
    mousedown: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("mousedown", function() {
            func();
        });
    },
    mouseup: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("mouseup", function() {
            func();
        });
    },
    mousemove: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("mousemove", function() {
            func();
        });
    },
    Keydown: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("Keydown", function() {
            func();
        });
    },
    focus: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("focus", function() {
            func();
        });
    },
    submit: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("submit", function() {
            func();
        });
    },
    blur: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("blur", function() {
            func();
        });
    },
    change: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("change", function() {
            func();
        });
    },
    load: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("load", function() {
            func();
        });
    },
    unload: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("unload", function() {
            func();
        });
    },
    resize: (element, func) => {

        if (element == window) {
            window.addEventListener("resize", function() {
                func();
            });
        } else {
            let el = document.querySelector(element);
            el.addEventListener("resize", function() {
                func();
            });

        }
    },
    Keydown: (element, func) => {
        let el = document.querySelector(element);
        el.addEventListener("Keydown", function() {
            func();
        });
    },
}


function hover(element, {
    background: coloro,
    width: w,
    height: he,
    position: pjh,
    color: cg,
    margin: mm,
    padding: pp,
    margin_top: mt,
    margin_bottom: mb,
    margin_left: ml,
    margin_right: mr,
    padding_top: pt,
    padding_bottom: pb,
    padding_left: pl,
    padding_right: pr,
    display: ds,
    transition: trs,
    transform: trf,
    opacity: ops,
    flex: flx,
    gap: gpa,
    text_align: txta,
    justify_content: jus,
    align_items: ait,
    box_shadow: bsx,
    top: opsf,
    bottom: btm,
    left: lef,
    right: rtl,
    text_shadow: txtsx,
    text_space: txts,
    border: bor,
    border_top: bot,
    border_bottom: bob,
    border_left: bol,
    border_right: bori,
    font_size: fts,
    font_family: ftf,
    font_display: ftd,
    font_style: ftst,
    font_weight: ftw,
    overflow: ovf,
    overflow_x: ovfx,
    overflow_y: ovfy,
    border_radius: borrad,
    line_height: lnh,
    cursor: cur,
    box_sizing: boxsdf,
    float: flot,
    text_decoration: txtdco,
    z_index: zin,
    content: cont,
    background_image: bci,
    background_position: bcp,
    background_color: bcc,
    max_width: maxw,
    min_width: minw,
    max_height: maxh,
    min_height: minh,
    clear: clr,
    outline: outl,
    animation: anim,
    animation_delay: animde,
    animation_duration: animdu,
    animation_fill_mode: animfm,
    animation_name: animn,
    flex_wrap: flxw,
    user_select: usel,
    visibility: visi,
    list_style: lst,
    list_style_type: lstst,
    flex_direction: flxdir,
    border_style: bsty,
    border_top_left_radius: btlr,
    border_top_right_radius: btrr,
    border_bottom_right_radius: bbrr,
    border_bottom_left_radius: bblr,
    fill: fil,
    filter: filt,
    order: ord,
    font: fon,
    src: srcf,
    columns: col,
    border_collapse: bordercolapse,
    border_image: borderimage,
    border_width: borderwidth,
    justify_items: justifyitems,
    justify_self: justifyself,
    justify_tracks: justifytracks,
    text_justify: txtjus,
    align_self: alisef,
    align_content: alicon,
    align_tracks: alitra,
    word_wrap: wordwrap,
    word_break: wordbr,
    pointer_events: pontev,
    direction: dirc,
    row_gap: rowgap,
    column_gap: colgap,
    border_bottom_color: bbc,
    border_top_color: btc,
    border_left_color: blc,
    border_right_color: brc,
    grid_template_areas: gta,
    grid_template_columns: gtc,
    grid_template_rows: gtr,
    grid_template: gtj,
    grid_row_end: gre,
    grid_row_start: grs,
}) {
    element.addEventListener("mousemove", function() {
        const a = document.querySelector(element).style.background = coloro;
        const b = document.querySelector(element).style.width = w;
        const c = document.querySelector(element).style.height = he;
        const d = document.querySelector(element).style.position = pjh;
        const e = document.querySelector(element).style.color = cg;
        const f = document.querySelector(element).style.margin = mm;
        const g = document.querySelector(element).style.padding = pp;
        const h = document.querySelector(element).style.marginTop = mt;
        const i = document.querySelector(element).style.marginBottom = mb;
        const j = document.querySelector(element).style.marginLeft = ml;
        const k = document.querySelector(element).style.marginRight = mr;
        const l = document.querySelector(element).style.paddingTop = pt;
        const m = document.querySelector(element).style.paddingBottom = pb;
        const n = document.querySelector(element).style.paddingLeft = pl;
        const o = document.querySelector(element).style.paddingRight = pr;
        const p = document.querySelector(element).style.display = ds;
        const q = document.querySelector(element).style.transition = trs;
        const r = document.querySelector(element).style.transform = trf;
        const s = document.querySelector(element).style.opacity = ops;
        const t = document.querySelector(element).style.flex = flx;
        const u = document.querySelector(element).style.gap = gpa;
        const v = document.querySelector(element).style.textAlign = txta;
        const ww = document.querySelector(element).style.justifyContent = jus;
        const x = document.querySelector(element).style.alignItems = ait;
        const y = document.querySelector(element).style.boxShadow = bsx;
        const z = document.querySelector(element).style.textSpace = txts;
        const aa = document.querySelector(element).style.textShadow = txtsx;
        const ba = document.querySelector(element).style.top = opsf;
        const ca = document.querySelector(element).style.bottom = btm;
        const da = document.querySelector(element).style.left = lef;
        const ea = document.querySelector(element).style.right = rtl;
        const fa = document.querySelector(element).style.border = bor;
        const ga = document.querySelector(element).style.borderTop = bot;
        const ha = document.querySelector(element).style.borderBottom = bob;
        const ia = document.querySelector(element).style.borderLeft = bol;
        const ja = document.querySelector(element).style.borderRight = bori;
        const ka = document.querySelector(element).style.fontSize = fts;
        const la = document.querySelector(element).style.fontFamily = ftf;
        const ma = document.querySelector(element).style.fontWeight = ftw;
        const oa = document.querySelector(element).style.fontStyle = ftst;
        const pa = document.querySelector(element).style.fontDisplay = ftd;
        const qa = document.querySelector(element).style.overflow = ovf;
        const ra = document.querySelector(element).style.overflowX = ovfx;
        const sa = document.querySelector(element).style.overflowY = ovfy;
        const ta = document.querySelector(element).style.borderRadius = borrad;
        const ua = document.querySelector(element).style.lineHeight = lnh;
        const va = document.querySelector(element).style.cursor = cur;
        const wa = document.querySelector(element).style.boxSizing = boxsdf;
        const xa = document.querySelector(element).style.float = flot;
        const ya = document.querySelector(element).style.textDecoration = txtdco;
        const za = document.querySelector(element).style.zIndex = zin;
        const ab = document.querySelector(element).style.content = cont;
        const bb = document.querySelector(element).style.backgroundImage = bci;
        const cb = document.querySelector(element).style.backgroundPosition = bcp;
        const eb = document.querySelector(element).style.backgroundColor = bcc;
        const fb = document.querySelector(element).style.maxWidth = maxw;
        const gb = document.querySelector(element).style.minWidth = minw;
        const hb = document.querySelector(element).style.maxHeight = maxh;
        const ib = document.querySelector(element).style.minHeight = minh;
        const jb = document.querySelector(element).style.clear = clr;
        const kb = document.querySelector(element).style.outline = outl;
        const lb = document.querySelector(element).style.animation = anim;
        const mbb = document.querySelector(element).style.animationName = animn;
        const nb = document.querySelector(element).style.animationDuration = animdu;
        const ob = document.querySelector(element).style.animationDelay = animde;
        const pbb = document.querySelector(element).style.animationFillMode = animfm;
        const qb = document.querySelector(element).style.flexWrap = flxw;
        const rb = document.querySelector(element).style.userSelect = usel;
        const sb = document.querySelector(element).style.visibility = visi;
        const tb = document.querySelector(element).style.listStyle = lst;
        const ub = document.querySelector(element).style.listStyleType = lstst;
        const vb = document.querySelector(element).style.flexDirection = flxdir;
        const bc = document.querySelector(element).style.borderTopLeftRadius = btlr;
        const cc = document.querySelector(element).style.borderTopRightRadius = btrr;
        const dc = document.querySelector(element).style.borderBottomRightRadius = bbrr;
        const fc = document.querySelector(element).style.borderBottomLeftRadius = bblr;
        const ac = document.querySelector(element).style.borderStyle = bsty;
        const gc = document.querySelector(element).style.fill = fil;
        const hc = document.querySelector(element).style.filter = filt;
        const ic = document.querySelector(element).style.order = ord;
        const jc = document.querySelector(element).style.columns = col;
        const kc = document.querySelector(element).style.font = fon;
        const lc = document.querySelector(element).style.src = srcf;
        const mc = document.querySelector(element).style.borderCollapse = bordercolapse;
        const nc = document.querySelector(element).style.borderImage = borderimage;
        const oc = document.querySelector(element).style.borderWidth = borderwidth;
        const pc = document.querySelector(element).style.justifyItems = justifyitems;
        const qc = document.querySelector(element).style.justifySelf = justifyself;
        const rc = document.querySelector(element).style.justifyTracks = justifytracks;
        const sc = document.querySelector(element).style.textJustify = txtjus;
        const tc = document.querySelector(element).style.alignSelf = alisef;
        const uc = document.querySelector(element).style.alignContent = alicon;
        const vc = document.querySelector(element).style.alignTracks = alitra;
        const wc = document.querySelector(element).style.wordWrap = wordwrap;
        const xc = document.querySelector(element).style.wordBreak = wordbr;
        const yc = document.querySelector(element).style.pointerEvents = pontev;
        const zc = document.querySelector(element).style.direction = dirc;
        const ad = document.querySelector(element).style.rowGap = rowgap;
        const bd = document.querySelector(element).style.columnGap = colgap;
        const cd = document.querySelector(element).style.borderBottomColor = bbc;
        const dd = document.querySelector(element).style.borderTopColor = btc;
        const ed = document.querySelector(element).style.borderLeftColor = blc;
        const fd = document.querySelector(element).style.borderRightColor = brc;
        const gd = document.querySelector(element).style.gridTemplateAreas = gta;
        const hd = document.querySelector(element).style.gridTemplateColumns = gtc;
        const ide = document.querySelector(element).style.gridTemplateRows = gtr;
        const jd = document.querySelector(element).style.gridTemplate = gtj;
        const kd = document.querySelector(element).style.gridRowEnd = gre;
        const ld = document.querySelector(element).style.gridRowStart = grs;
    });
}

function loader(type, {
    color: coloro,
    size: sizee,
    stroke: st,
    speed: sp
}) {
    if (type == true) {
        style(".loader", {
            width: sizee,
            height: sizee,
            border: st + " solid " + coloro,
            border_right: st + " solid transparent",
            border_radius: "100px",
            transition: sp,
        });
    } else if (type == false) {} else { console.error("not found !!"); }
}


function script(code) {
    code();
}


function style(element, {
    background: coloro,
    width: w,
    height: he,
    position: pjh,
    color: cg,
    margin: mm,
    padding: pp,
    margin_top: mt,
    margin_bottom: mb,
    margin_left: ml,
    margin_right: mr,
    padding_top: pt,
    padding_bottom: pb,
    padding_left: pl,
    padding_right: pr,
    display: ds,
    transition: trs,
    transform: trf,
    opacity: ops,
    flex: flx,
    gap: gpa,
    text_align: txta,
    justify_content: jus,
    align_items: ait,
    box_shadow: bsx,
    top: opsf,
    bottom: btm,
    left: lef,
    right: rtl,
    text_shadow: txtsx,
    text_space: txts,
    border: bor,
    border_top: bot,
    border_bottom: bob,
    border_left: bol,
    border_right: bori,
    font_size: fts,
    font_family: ftf,
    font_display: ftd,
    font_style: ftst,
    font_weight: ftw,
    overflow: ovf,
    overflow_x: ovfx,
    overflow_y: ovfy,
    border_radius: borrad,
    line_height: lnh,
    cursor: cur,
    box_sizing: boxsdf,
    float: flot,
    text_decoration: txtdco,
    z_index: zin,
    content: cont,
    background_image: bci,
    background_position: bcp,
    background_color: bcc,
    max_width: maxw,
    min_width: minw,
    max_height: maxh,
    min_height: minh,
    clear: clr,
    outline: outl,
    animation: anim,
    animation_delay: animde,
    animation_duration: animdu,
    animation_fill_mode: animfm,
    animation_name: animn,
    flex_wrap: flxw,
    user_select: usel,
    visibility: visi,
    list_style: lst,
    list_style_type: lstst,
    flex_direction: flxdir,
    border_style: bsty,
    border_top_left_radius: btlr,
    border_top_right_radius: btrr,
    border_bottom_right_radius: bbrr,
    border_bottom_left_radius: bblr,
    fill: fil,
    filter: filt,
    order: ord,
    font: fon,
    src: srcf,
    columns: col,
    border_collapse: bordercolapse,
    border_image: borderimage,
    border_width: borderwidth,
    justify_items: justifyitems,
    justify_self: justifyself,
    justify_tracks: justifytracks,
    text_justify: txtjus,
    align_self: alisef,
    align_content: alicon,
    align_tracks: alitra,
    word_wrap: wordwrap,
    word_break: wordbr,
    pointer_events: pontev,
    direction: dirc,
    row_gap: rowgap,
    column_gap: colgap,
    border_bottom_color: bbc,
    border_top_color: btc,
    border_left_color: blc,
    border_right_color: brc,
    grid_template_areas: gta,
    grid_template_columns: gtc,
    grid_template_rows: gtr,
    grid_template: gtj,
    grid_row_end: gre,
    grid_row_start: grs,

}) {
    const a = document.querySelector(element).style.background = coloro;
    const b = document.querySelector(element).style.width = w;
    const c = document.querySelector(element).style.height = he;
    const d = document.querySelector(element).style.position = pjh;
    const e = document.querySelector(element).style.color = cg;
    const f = document.querySelector(element).style.margin = mm;
    const g = document.querySelector(element).style.padding = pp;
    const h = document.querySelector(element).style.marginTop = mt;
    const i = document.querySelector(element).style.marginBottom = mb;
    const j = document.querySelector(element).style.marginLeft = ml;
    const k = document.querySelector(element).style.marginRight = mr;
    const l = document.querySelector(element).style.paddingTop = pt;
    const m = document.querySelector(element).style.paddingBottom = pb;
    const n = document.querySelector(element).style.paddingLeft = pl;
    const o = document.querySelector(element).style.paddingRight = pr;
    const p = document.querySelector(element).style.display = ds;
    const q = document.querySelector(element).style.transition = trs;
    const r = document.querySelector(element).style.transform = trf;
    const s = document.querySelector(element).style.opacity = ops;
    const t = document.querySelector(element).style.flex = flx;
    const u = document.querySelector(element).style.gap = gpa;
    const v = document.querySelector(element).style.textAlign = txta;
    const ww = document.querySelector(element).style.justifyContent = jus;
    const x = document.querySelector(element).style.alignItems = ait;
    const y = document.querySelector(element).style.boxShadow = bsx;
    const z = document.querySelector(element).style.textSpace = txts;
    const aa = document.querySelector(element).style.textShadow = txtsx;
    const ba = document.querySelector(element).style.top = opsf;
    const ca = document.querySelector(element).style.bottom = btm;
    const da = document.querySelector(element).style.left = lef;
    const ea = document.querySelector(element).style.right = rtl;
    const fa = document.querySelector(element).style.border = bor;
    const ga = document.querySelector(element).style.borderTop = bot;
    const ha = document.querySelector(element).style.borderBottom = bob;
    const ia = document.querySelector(element).style.borderLeft = bol;
    const ja = document.querySelector(element).style.borderRight = bori;
    const ka = document.querySelector(element).style.fontSize = fts;
    const la = document.querySelector(element).style.fontFamily = ftf;
    const ma = document.querySelector(element).style.fontWeight = ftw;
    const oa = document.querySelector(element).style.fontStyle = ftst;
    const pa = document.querySelector(element).style.fontDisplay = ftd;
    const qa = document.querySelector(element).style.overflow = ovf;
    const ra = document.querySelector(element).style.overflowX = ovfx;
    const sa = document.querySelector(element).style.overflowY = ovfy;
    const ta = document.querySelector(element).style.borderRadius = borrad;
    const ua = document.querySelector(element).style.lineHeight = lnh;
    const va = document.querySelector(element).style.cursor = cur;
    const wa = document.querySelector(element).style.boxSizing = boxsdf;
    const xa = document.querySelector(element).style.float = flot;
    const ya = document.querySelector(element).style.textDecoration = txtdco;
    const za = document.querySelector(element).style.zIndex = zin;
    const ab = document.querySelector(element).style.content = cont;
    const bb = document.querySelector(element).style.backgroundImage = bci;
    const cb = document.querySelector(element).style.backgroundPosition = bcp;
    const eb = document.querySelector(element).style.backgroundColor = bcc;
    const fb = document.querySelector(element).style.maxWidth = maxw;
    const gb = document.querySelector(element).style.minWidth = minw;
    const hb = document.querySelector(element).style.maxHeight = maxh;
    const ib = document.querySelector(element).style.minHeight = minh;
    const jb = document.querySelector(element).style.clear = clr;
    const kb = document.querySelector(element).style.outline = outl;
    const lb = document.querySelector(element).style.animation = anim;
    const mbb = document.querySelector(element).style.animationName = animn;
    const nb = document.querySelector(element).style.animationDuration = animdu;
    const ob = document.querySelector(element).style.animationDelay = animde;
    const pbb = document.querySelector(element).style.animationFillMode = animfm;
    const qb = document.querySelector(element).style.flexWrap = flxw;
    const rb = document.querySelector(element).style.userSelect = usel;
    const sb = document.querySelector(element).style.visibility = visi;
    const tb = document.querySelector(element).style.listStyle = lst;
    const ub = document.querySelector(element).style.listStyleType = lstst;
    const vb = document.querySelector(element).style.flexDirection = flxdir;
    const bc = document.querySelector(element).style.borderTopLeftRadius = btlr;
    const cc = document.querySelector(element).style.borderTopRightRadius = btrr;
    const dc = document.querySelector(element).style.borderBottomRightRadius = bbrr;
    const fc = document.querySelector(element).style.borderBottomLeftRadius = bblr;
    const ac = document.querySelector(element).style.borderStyle = bsty;
    const gc = document.querySelector(element).style.fill = fil;
    const hc = document.querySelector(element).style.filter = filt;
    const ic = document.querySelector(element).style.order = ord;
    const jc = document.querySelector(element).style.columns = col;
    const kc = document.querySelector(element).style.font = fon;
    const lc = document.querySelector(element).style.src = srcf;
    const mc = document.querySelector(element).style.borderCollapse = bordercolapse;
    const nc = document.querySelector(element).style.borderImage = borderimage;
    const oc = document.querySelector(element).style.borderWidth = borderwidth;
    const pc = document.querySelector(element).style.justifyItems = justifyitems;
    const qc = document.querySelector(element).style.justifySelf = justifyself;
    const rc = document.querySelector(element).style.justifyTracks = justifytracks;
    const sc = document.querySelector(element).style.textJustify = txtjus;
    const tc = document.querySelector(element).style.alignSelf = alisef;
    const uc = document.querySelector(element).style.alignContent = alicon;
    const vc = document.querySelector(element).style.alignTracks = alitra;
    const wc = document.querySelector(element).style.wordWrap = wordwrap;
    const xc = document.querySelector(element).style.wordBreak = wordbr;
    const yc = document.querySelector(element).style.pointerEvents = pontev;
    const zc = document.querySelector(element).style.direction = dirc;
    const ad = document.querySelector(element).style.rowGap = rowgap;
    const bd = document.querySelector(element).style.columnGap = colgap;
    const cd = document.querySelector(element).style.borderBottomColor = bbc;
    const dd = document.querySelector(element).style.borderTopColor = btc;
    const ed = document.querySelector(element).style.borderLeftColor = blc;
    const fd = document.querySelector(element).style.borderRightColor = brc;
    const gd = document.querySelector(element).style.gridTemplateAreas = gta;
    const hd = document.querySelector(element).style.gridTemplateColumns = gtc;
    const ide = document.querySelector(element).style.gridTemplateRows = gtr;
    const jd = document.querySelector(element).style.gridTemplate = gtj;
    const kd = document.querySelector(element).style.gridRowEnd = gre;
    const ld = document.querySelector(element).style.gridRowStart = grs;
}

function _(element, {
    background: coloro,
    width: w,
    height: he,
    position: pjh,
    color: cg,
    margin: mm,
    padding: pp,
    margin_top: mt,
    margin_bottom: mb,
    margin_left: ml,
    margin_right: mr,
    padding_top: pt,
    padding_bottom: pb,
    padding_left: pl,
    padding_right: pr,
    display: ds,
    transition: trs,
    transform: trf,
    opacity: ops,
    flex: flx,
    gap: gpa,
    text_align: txta,
    justify_content: jus,
    align_items: ait,
    box_shadow: bsx,
    top: opsf,
    bottom: btm,
    left: lef,
    right: rtl,
    text_shadow: txtsx,
    text_space: txts,
    border: bor,
    border_top: bot,
    border_bottom: bob,
    border_left: bol,
    border_right: bori,
    font_size: fts,
    font_family: ftf,
    font_display: ftd,
    font_style: ftst,
    font_weight: ftw,
    overflow: ovf,
    overflow_x: ovfx,
    overflow_y: ovfy,
    border_radius: borrad,
    line_height: lnh,
    cursor: cur,
    box_sizing: boxsdf,
    float: flot,
    text_decoration: txtdco,
    z_index: zin,
    content: cont,
    background_image: bci,
    background_position: bcp,
    background_color: bcc,
    max_width: maxw,
    min_width: minw,
    max_height: maxh,
    min_height: minh,
    clear: clr,
    outline: outl,
    animation: anim,
    animation_delay: animde,
    animation_duration: animdu,
    animation_fill_mode: animfm,
    animation_name: animn,
    flex_wrap: flxw,
    user_select: usel,
    visibility: visi,
    list_style: lst,
    list_style_type: lstst,
    flex_direction: flxdir,
    border_style: bsty,
    border_top_left_radius: btlr,
    border_top_right_radius: btrr,
    border_bottom_right_radius: bbrr,
    border_bottom_left_radius: bblr,
    fill: fil,
    filter: filt,
    order: ord,
    font: fon,
    src: srcf,
    columns: col,
    border_collapse: bordercolapse,
    border_image: borderimage,
    border_width: borderwidth,
    justify_items: justifyitems,
    justify_self: justifyself,
    justify_tracks: justifytracks,
    text_justify: txtjus,
    align_self: alisef,
    align_content: alicon,
    align_tracks: alitra,
    word_wrap: wordwrap,
    word_break: wordbr,
    pointer_events: pontev,
    direction: dirc,
    row_gap: rowgap,
    column_gap: colgap,
    border_bottom_color: bbc,
    border_top_color: btc,
    border_left_color: blc,
    border_right_color: brc,
    grid_template_areas: gta,
    grid_template_columns: gtc,
    grid_template_rows: gtr,
    grid_template: gtj,
    grid_row_end: gre,
    grid_row_start: grs,

}) {
    const a = document.querySelector(element).style.background = coloro;
    const b = document.querySelector(element).style.width = w;
    const c = document.querySelector(element).style.height = he;
    const d = document.querySelector(element).style.position = pjh;
    const e = document.querySelector(element).style.color = cg;
    const f = document.querySelector(element).style.margin = mm;
    const g = document.querySelector(element).style.padding = pp;
    const h = document.querySelector(element).style.marginTop = mt;
    const i = document.querySelector(element).style.marginBottom = mb;
    const j = document.querySelector(element).style.marginLeft = ml;
    const k = document.querySelector(element).style.marginRight = mr;
    const l = document.querySelector(element).style.paddingTop = pt;
    const m = document.querySelector(element).style.paddingBottom = pb;
    const n = document.querySelector(element).style.paddingLeft = pl;
    const o = document.querySelector(element).style.paddingRight = pr;
    const p = document.querySelector(element).style.display = ds;
    const q = document.querySelector(element).style.transition = trs;
    const r = document.querySelector(element).style.transform = trf;
    const s = document.querySelector(element).style.opacity = ops;
    const t = document.querySelector(element).style.flex = flx;
    const u = document.querySelector(element).style.gap = gpa;
    const v = document.querySelector(element).style.textAlign = txta;
    const ww = document.querySelector(element).style.justifyContent = jus;
    const x = document.querySelector(element).style.alignItems = ait;
    const y = document.querySelector(element).style.boxShadow = bsx;
    const z = document.querySelector(element).style.textSpace = txts;
    const aa = document.querySelector(element).style.textShadow = txtsx;
    const ba = document.querySelector(element).style.top = opsf;
    const ca = document.querySelector(element).style.bottom = btm;
    const da = document.querySelector(element).style.left = lef;
    const ea = document.querySelector(element).style.right = rtl;
    const fa = document.querySelector(element).style.border = bor;
    const ga = document.querySelector(element).style.borderTop = bot;
    const ha = document.querySelector(element).style.borderBottom = bob;
    const ia = document.querySelector(element).style.borderLeft = bol;
    const ja = document.querySelector(element).style.borderRight = bori;
    const ka = document.querySelector(element).style.fontSize = fts;
    const la = document.querySelector(element).style.fontFamily = ftf;
    const ma = document.querySelector(element).style.fontWeight = ftw;
    const oa = document.querySelector(element).style.fontStyle = ftst;
    const pa = document.querySelector(element).style.fontDisplay = ftd;
    const qa = document.querySelector(element).style.overflow = ovf;
    const ra = document.querySelector(element).style.overflowX = ovfx;
    const sa = document.querySelector(element).style.overflowY = ovfy;
    const ta = document.querySelector(element).style.borderRadius = borrad;
    const ua = document.querySelector(element).style.lineHeight = lnh;
    const va = document.querySelector(element).style.cursor = cur;
    const wa = document.querySelector(element).style.boxSizing = boxsdf;
    const xa = document.querySelector(element).style.float = flot;
    const ya = document.querySelector(element).style.textDecoration = txtdco;
    const za = document.querySelector(element).style.zIndex = zin;
    const ab = document.querySelector(element).style.content = cont;
    const bb = document.querySelector(element).style.backgroundImage = bci;
    const cb = document.querySelector(element).style.backgroundPosition = bcp;
    const eb = document.querySelector(element).style.backgroundColor = bcc;
    const fb = document.querySelector(element).style.maxWidth = maxw;
    const gb = document.querySelector(element).style.minWidth = minw;
    const hb = document.querySelector(element).style.maxHeight = maxh;
    const ib = document.querySelector(element).style.minHeight = minh;
    const jb = document.querySelector(element).style.clear = clr;
    const kb = document.querySelector(element).style.outline = outl;
    const lb = document.querySelector(element).style.animation = anim;
    const mbb = document.querySelector(element).style.animationName = animn;
    const nb = document.querySelector(element).style.animationDuration = animdu;
    const ob = document.querySelector(element).style.animationDelay = animde;
    const pbb = document.querySelector(element).style.animationFillMode = animfm;
    const qb = document.querySelector(element).style.flexWrap = flxw;
    const rb = document.querySelector(element).style.userSelect = usel;
    const sb = document.querySelector(element).style.visibility = visi;
    const tb = document.querySelector(element).style.listStyle = lst;
    const ub = document.querySelector(element).style.listStyleType = lstst;
    const vb = document.querySelector(element).style.flexDirection = flxdir;
    const bc = document.querySelector(element).style.borderTopLeftRadius = btlr;
    const cc = document.querySelector(element).style.borderTopRightRadius = btrr;
    const dc = document.querySelector(element).style.borderBottomRightRadius = bbrr;
    const fc = document.querySelector(element).style.borderBottomLeftRadius = bblr;
    const ac = document.querySelector(element).style.borderStyle = bsty;
    const gc = document.querySelector(element).style.fill = fil;
    const hc = document.querySelector(element).style.filter = filt;
    const ic = document.querySelector(element).style.order = ord;
    const jc = document.querySelector(element).style.columns = col;
    const kc = document.querySelector(element).style.font = fon;
    const lc = document.querySelector(element).style.src = srcf;
    const mc = document.querySelector(element).style.borderCollapse = bordercolapse;
    const nc = document.querySelector(element).style.borderImage = borderimage;
    const oc = document.querySelector(element).style.borderWidth = borderwidth;
    const pc = document.querySelector(element).style.justifyItems = justifyitems;
    const qc = document.querySelector(element).style.justifySelf = justifyself;
    const rc = document.querySelector(element).style.justifyTracks = justifytracks;
    const sc = document.querySelector(element).style.textJustify = txtjus;
    const tc = document.querySelector(element).style.alignSelf = alisef;
    const uc = document.querySelector(element).style.alignContent = alicon;
    const vc = document.querySelector(element).style.alignTracks = alitra;
    const wc = document.querySelector(element).style.wordWrap = wordwrap;
    const xc = document.querySelector(element).style.wordBreak = wordbr;
    const yc = document.querySelector(element).style.pointerEvents = pontev;
    const zc = document.querySelector(element).style.direction = dirc;
    const ad = document.querySelector(element).style.rowGap = rowgap;
    const bd = document.querySelector(element).style.columnGap = colgap;
    const cd = document.querySelector(element).style.borderBottomColor = bbc;
    const dd = document.querySelector(element).style.borderTopColor = btc;
    const ed = document.querySelector(element).style.borderLeftColor = blc;
    const fd = document.querySelector(element).style.borderRightColor = brc;
    const gd = document.querySelector(element).style.gridTemplateAreas = gta;
    const hd = document.querySelector(element).style.gridTemplateColumns = gtc;
    const ide = document.querySelector(element).style.gridTemplateRows = gtr;
    const jd = document.querySelector(element).style.gridTemplate = gtj;
    const kd = document.querySelector(element).style.gridRowEnd = gre;
    const ld = document.querySelector(element).style.gridRowStart = grs;
}


function AddToList(ArrayName, val) {
    ArrayName.push(val);
}


function PublicRandom(number) {
    let rand = Math.floor(Math.random() * number);
    return rand;
}